# Facade Pattern Lab — Airline Booking

Java implementation of Phase 1 and Phase 2 from FacadePatternLabTask.pdf.

## Files
- Five supplied read-only subsystem classes
- `FlightBookingFacade.java`: both 8-argument and 9-argument booking methods
- `Main.java`: four required test scenarios

## Run
Requires JDK 15 or newer.

```bash
javac *.java
java Main
```

## Expected checks
1. Successful booking returns an ETKT code.
2. Row 13 is blocked, without terminating the program.
3. Invalid card triggers `Released lock: LOCK-KC101-07D` before disconnect.
4. SILVER skips baggage engine and applies a 10% discount (320 USD -> 288 USD).

## GitHub submission
Create a **new** repository whose name ends with your student ID, e.g. `FacadePatternLab-YOUR_STUDENT_ID`.
To show Phase 1 and Phase 2 separately in Git history, commit the Phase 1 version before adding the loyalty overload and Test 4. This ZIP contains the completed final version; do not claim it has a two-stage commit history.
